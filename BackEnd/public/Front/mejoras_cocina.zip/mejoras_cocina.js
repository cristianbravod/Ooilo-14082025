
// Función para obtener ícono según estado
function getEstadoIcono(estado) {
    switch (estado) {
        case 'pendiente': return '⏳';
        case 'preparando': return '🔥';
        case 'listo': return '✅';
        case 'entregada': return '🚚';
        default: return '📦';
    }
}

// Ejemplo de renderizado de un ítem con estado mejorado
function renderItem(item) {
    return `
        <div class="order-item">
            <div class="item-info">
                <div class="item-name">${item.nombre}</div>
                <div class="item-details">
                    <span class="item-quantity">${item.cantidad}x</span>
                    <span class="item-price">$${(item.precio * item.cantidad).toLocaleString('es-CL')}</span>
                    <span class="item-status ${item.estado}">
                        ${getEstadoIcono(item.estado)} ${(ITEM_STATES[item.estado] || { label: 'Desconocido' }).label}
                    </span>
                </div>
                ${item.observaciones ? `<div class="item-observations">📝 ${item.observaciones}</div>` : ''}
            </div>
        </div>
    `;
}

// Ejemplo de renderizado de cabecera de orden
function renderOrderHeader(order) {
    const stateInfo = ORDER_STATES[order.estado] || ORDER_STATES['pendiente'];
    return `
        <div class="order-header ${'status-' + order.estado}">
            <div>
                <div class="order-mesa">${order.mesa}</div>
                <div class="order-time">Hace ${order.minutos_espera} min</div>
            </div>
            <div class="status-badge">
                ${getEstadoIcono(order.estado)} ${stateInfo.label}
            </div>
        </div>
    `;
}
